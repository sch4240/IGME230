//this function will store all of the values in the game in localstorage
function storeValues(totalBytes, clickScore, clickPower, highScore, miniMiner, miner, megaMiner, minerManager, clawMiner, explosives, hackers, keyboard, bytes, shorts, ints, longs, floats, doubles, chars, bools, set){
    localStorage.setItem("TotalBytes", totalBytes);
    localStorage.setItem("ClickAmount", clickScore);
    localStorage.setItem("ClickPower", clickPower);
    localStorage.setItem("HighScore", highScore);
    localStorage.setItem("MiniMiners", miniMiner);
    localStorage.setItem("Miners", miner);
    localStorage.setItem("MegaMiners", megaMiner);
    localStorage.setItem("MinerManagers", minerManager);
    localStorage.setItem("ClawMiners", clawMiner);
    localStorage.setItem("HTMLExplosives", explosives);
    localStorage.setItem("80sHackers", hackers);
    localStorage.setItem("ExtraKeyboards", keyboard);
    localStorage.setItem("ByteBonus", bytes);
    localStorage.setItem("ShortBonus", shorts);
    localStorage.setItem("IntBonus", ints);
    localStorage.setItem("LongBonus", longs);
    localStorage.setItem("FloatBonus", floats);
    localStorage.setItem("DoubleBonus", doubles);
    localStorage.setItem("CharBonus", chars);
    localStorage.setItem("BoolBonus", bools);
    localStorage.setItem("Set", set);
    
    //these check if these values exist and handle it accordingly
    if(totalBytes == null || totalBytes == undefined || totalBytes == NaN){
        localStorage.setItem("TotalBytes", 0);
    }
    if(clickScore == null || clickScore == undefined || totalBytes == NaN){
        localStorage.setItem("ClickAmount", 0);
    }
    if(clickPower == null || clickPower == undefined || totalBytes == NaN){
        localStorage.setItem("ClickPower", 0);
    }
    if(highScore == null || highScore == undefined || totalBytes == NaN){
        localStorage.setItem("HighScore", 0);
    }
    if(miniMiner == null || miniMiner == undefined || totalBytes == NaN){
        localStorage.setItem("MiniMiners", 0);
    }
    if(miner == null || miner == undefined || totalBytes == NaN){
        localStorage.setItem("Miners", 0);
    }
    if(megaMiner == null || megaMiner == undefined || totalBytes == NaN){
        localStorage.setItem("MegaMiners", 0);
    }
    if(minerManager == null || minerManager == undefined){
        localStorage.setItem("MinerManagers", 0);
    }
    if(clawMiner == null || clawMiner == undefined){
        localStorage.setItem("ClawMiners", 0);
    }
    if(explosives == null || explosives == undefined){
        localStorage.setItem("HTMLExplosives", 0);
    }
    if(hackers == null || hackers == undefined){
        localStorage.setItem("80sHackers", 0);
    }
    if(keyboard == null || keyboard == undefined){
        localStorage.setItem("ExtraKeyboards", 0);
    }
    if(bytes == null || bytes == undefined){
        localStorage.setItem("ByteBonus", 0);
    }
    if(shorts == null || shorts == undefined){
        localStorage.setItem("ShortBonus", 0);
    }
    if(ints == null || ints == undefined){
        localStorage.setItem("IntBonus", 0);
    }
    if(longs == null || longs == undefined){
        localStorage.setItem("LongBonus", 0);
    }
    if(floats == null || floats == undefined){
        localStorage.setItem("FloatBonus", 0);
    }
    if(doubles == null || doubles == undefined){
        localStorage.setItem("DoubleBonus", 0);
    }
    if(chars == null || chars == undefined){
        localStorage.setItem("CharBonus", 0);
    }
    if(bools == null ||bools== undefined){
        localStorage.setItem("BoolBonus", 0);
    }
}


