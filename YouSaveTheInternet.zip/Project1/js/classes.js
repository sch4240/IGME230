class Arrow extends PIXI.Sprite{
	constructor(x=0, y=0, direction){
		super(PIXI.loader.resources["images/arrow"+direction+".png"].texture);
        this.direction = direction;
		this.anchor.set(0.5,0.5);
		this.x = x;
        this.speed = 100;
		this.y = y;
        this.hit = false;
	}
    
    move(dt=1/60){
		this.y += this.speed *dt;
	}
}

class Earth extends PIXI.Sprite{
    constructor(){
        super(PIXI.loader.resources["images/earth.png"].texture);
    }
}

class Button extends PIXI.Sprite{
	constructor(x=0, y=0){
		super(PIXI.loader.resources["images/button.png"].texture);
		this.x = x;
		this.y = y;
	}
}

class Music extends Button{
    constructor(title, track){
        super();
        this.title = title;
        this.track = track;
        let buttonStyle = new PIXI.TextStyle({
		fill: 0x00FF00,
		fontSize: 24,
		fontFamily: "Verdana"
	});
        this.scale.set(0.5);
        let titleLabel = new PIXI.Text(this.title);
        titleLabel.style = buttonStyle;
        titleLabel.x = 45;
        titleLabel.y = 15;
        this.addChild(titleLabel);
    }
    
    playTrack(){
        for(let s of soundArr){
            s.stopTrack();
        }
        this.track.play();
    }
    
    stopTrack(){
        this.track.stop();
    }
}

class Upgrade extends Button{
    constructor(cost, amount, name, img, bonus, type){
        super();
        this.cost = amount*cost+cost;
        this.amount = amount;
        this.name = name;
        this.img = new PIXI.Sprite.fromImage(img);;
        this.bonus= bonus;
        this.type = type;
        this.interactive = true;
	    this.buttonMode = true;
    }
    
    
    addLabels(){
        let buttonStyle = new PIXI.TextStyle({
		fill: 0x00FF00,
		fontSize: 10,
		fontFamily: "Verdana"
	});
        this.addChild(this.img);
        this.img.x = 7;
        this.img.y = 20;
        let costLabel = new PIXI.Text(`Cost: ${this.cost}B`);
        this.costLabel = costLabel;
        if(this.cost>=1000){
            this.costLabel = new PIXI.Text(`Cost: ${Math.floor(this.cost)/1000}KB`);
        }else{
            this.costLabel = new PIXI.Text(`Cost: ${Math.floor(this.cost)}B`);
        }
        this.costLabel.style = buttonStyle;
        this.addChild(this.costLabel);
        this.costLabel.x = 115;
        this.costLabel.y = 28;
        let amountLabel = new PIXI.Text(`${this.amount}`);
        this.amountLabel = amountLabel;
        this.amountLabel.style = buttonStyle;
        this.addChild(this.amountLabel);
        this.amountLabel.x = 160;
        this.amountLabel.y = 7;
        let bonusLabel = new PIXI.Text(`Adds: ${this.bonus}B`);
        if(this.bonus>=500){
            bonusLabel= new PIXI.Text(`Adds: ${this.bonus/1000}KB`);
        }else{
            bonusLabel = new PIXI.Text(`Adds: ${this.bonus}B`);
        }
        bonusLabel.style = buttonStyle;
        this.addChild(bonusLabel);
        bonusLabel.x = 50;
        bonusLabel.y = 28;
        let nameLabel = new PIXI.Text(this.name);
        nameLabel.style = buttonStyle;
        this.addChild(nameLabel);
        nameLabel.x = 70;
        nameLabel.y = 7;
        
    }
    
    updateLabels(){
        this.removeChild(this.costLabel);
        this.removeChild(this.amountLabel);
        let buttonStyle = new PIXI.TextStyle({
		fill: 0x00FF00,
		fontSize: 10,
		fontFamily: "Verdana"
	});
        let costLabel = new PIXI.Text(`Cost: ${Math.floor(this.cost)}B`);
        this.costLabel = costLabel;
        if(this.cost >1000){
        costLabel.text = `Cost: ${Math.floor(this.cost/1000)}KB`;
        }else
        if(this.cost >1000000){
        costLabel.text = `Cost: ${Math.floor(this.cost/1000000)}MB`;
        }else
        if(this.cost >1000000000){
        costLabel.text = `Cost: ${Math.floor(this.cost/1000000000)}GB`;
        }else
        if(this.cost >1000000000000){
        costLabel.text = `Cost: ${Math.floor(this.cost/1000000000000)}TB`;
        }else
        if(this.cost >1000000000000000){
        costLabel.text = `Cost: ${Math.floor(this.cost/1000000000000000)}PB`;
        }else
        if(this.cost >1000000000000000000){
        costLabel.text = `Cost: ${Math.floor(this.cost/1000000000000000000)}EB`;
        }else{
           costLabel.text = `Cost: ${Math.floor(this.cost)}B`;
       }
        this.costLabel.style = buttonStyle;
        this.costLabel.x = 115;
        this.costLabel.y = 28;
        this.addChild(this.costLabel);
        let amountLabel = new PIXI.Text(`${Math.floor(this.amount)}`);
        this.amountLabel = amountLabel;
        this.amountLabel.style = buttonStyle;
        this.amountLabel.x = 160;
        this.amountLabel.y = 7;
        this.addChild(this.amountLabel);
    }
    
    buyUpgrade()
    {
        if(this.cost <= score)
        {
            
            if(this.type == "Bps")
            {
            score-=this.cost;  
            bps += this.bonus;
            this.purchase();
            this.updateLabels();
            moneySfx.play();
            }
            else
            {
                score -= this.cost;  
                clickPower += this.bonus;
                this.purchase();
                this.updateLabels();
                moneySfx.play();
            }
        }
        
    } 
    purchase(){
        this.cost *= 1.5;
        this.amount++;
    }
}

function rectsIntersect(a,b){
		var ab = a.getBounds();
		var bb = b.getBounds();
		return ab.x + ab.width > bb.x && ab.x < bb.x + bb.width && ab.y + ab.height > bb.y && ab.y < bb.y + bb.height;
	}

