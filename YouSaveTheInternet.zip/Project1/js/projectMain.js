"use strict";
const app = new PIXI.Application(800,800);
document.body.appendChild(app.view);
// constants
const sceneWidth = app.view.width;
const sceneHeight = app.view.height;

PIXI.loader.
add(["images/button.png","images/arrowUp.png", "images/arrowDown.png", "images/arrowLeft.png", "images/arrowRight.png", "images/miner.png", "images/manager.png", "images/earth.png", "images/claw.png","images/explosives.png","images/hacker.png","images/keyboard.png","images/byte.png","images/short.png", "images/int.png", "images/long.png", "images/float.png","images/double.png","images/char.png","images/bool.png"]).
on("progress",e=>{console.log(`progress=${e.progress}`);}).
load(setup);
// aliases
let stage;
//a whole lot of variables that do a lot of things
let startScene, gameScene, shopScene, shopScene2, titleLabel, scoreLabel, scoreLabel2, bpsLabel, clickPowerLabel, gameLabel, menuLabel1, menuLabel2, localLabel, score, bps, clickPower, highScore, miniMiner, miner, megaMiner, minerManager, claw, explosives, hacker, keyboard, bytes, shorts, ints, longs, floats, doubles, chars, bools, miniMinerScore, minerScore, megaMinerScore, managerScore, clawScore, explosiveScore, hackerScore, keyboardScore, byteScore, shortScore, intScore, longScore, floatScore, doubleScore, charScore, boolScore, leftIndicator, upIndicator, downIndicator, rightIndicator, checkKey, gameSpeed, arrows, localScore, stop, gameScoreLabel, highScoreLabel, playAgainLabel, track1, track2, track3, moneySfx, soundArr;

function setup(){
//MAIN MENU
stage = app.stage;
startScene = new PIXI.Container();
stage.addChild(startScene);
//UPGRADE MENU SETUP
//get values from local storage
if(!localStorage.getItem("TotalBytes")){
    storeValues(score, bps, clickPower, highScore, miniMinerScore, minerScore, megaMinerScore, managerScore, clawScore, explosiveScore, hackerScore, keyboardScore, byteScore, shortScore, intScore, longScore, floatScore, doubleScore, charScore, boolScore);
}
score = parseInt(localStorage.getItem("TotalBytes"));
bps = parseInt(localStorage.getItem("ClickAmount"));
clickPower = parseInt(localStorage.getItem("ClickPower"));
highScore = parseInt(localStorage.getItem("HighScore"));
miniMinerScore =parseInt(localStorage.getItem("MiniMiners"));
minerScore =parseInt(localStorage.getItem("Miners"));
megaMinerScore =parseInt(localStorage.getItem("MegaMiners"));
managerScore =parseInt(localStorage.getItem("MinerManagers"));
clawScore =parseInt(localStorage.getItem("ClawMiners"));
explosiveScore =parseInt(localStorage.getItem("HTMLExplosives"));
hackerScore =parseInt(localStorage.getItem("80sHackers"));
keyboardScore =parseInt(localStorage.getItem("ExtraKeyboards"));
byteScore =parseInt(localStorage.getItem("ByteBonus"));
shortScore=parseInt(localStorage.getItem("ShortBonus"));
intScore=parseInt(localStorage.getItem("IntBonus"));
longScore=parseInt(localStorage.getItem("LongBonus"));
floatScore=parseInt(localStorage.getItem("FloatBonus"));
doubleScore=parseInt(localStorage.getItem("DoubleBonus"));
charScore=parseInt(localStorage.getItem("CharBonus"));
boolScore=parseInt(localStorage.getItem("BoolBonus"));
if(localStorage.getItem("TotalBytes")){
    storeValues(score, bps, clickPower, highScore, miniMinerScore, minerScore, megaMinerScore, managerScore, clawScore, explosiveScore, hackerScore, keyboardScore, byteScore, shortScore, intScore, longScore, floatScore, doubleScore, charScore, boolScore);
}
shopScene = new PIXI.Container();
shopScene.visible = false;
stage.addChild(shopScene);
//GAME SETUP
gameScene = new PIXI.Container();
gameScene.visible = false;
stage.addChild(gameScene);
//UPGRADE MENU 2 SETUP
shopScene2 = new PIXI.Container();
shopScene2.visible = false;
stage.addChild(shopScene2);
//setting some starting values
setInterval(idle, 2000/60);
gameSpeed = 10000;
setInterval(gameLoop, gameSpeed/30);
setInterval(updateMovement, 1/12);
//arrays for the sounds and the arrows of the minigame
arrows = [];
soundArr = [];
localScore = 0;
clickPower += 1;
//makes the page responsive to keypresses
document.onkeydown = onKeyDown;
stop = false;
//creates the music and sound effects
track1 = new Howl({
		src: ['music/We_Are.mp3'],
        loop: true,
        volume: 0.5,
	});
track2 = new Howl({
		src: ['music/Get_Back.mp3'],
        loop: true,
        volume: 0.5,
	});
track3 = new Howl({
		src: ['music/Byte.mp3'],
        loop: true,
        volume: 0.5,
	});
moneySfx = new Howl({
		src: ['music/money.mp3'],
        volume: 0.8,
	});
    //creates all the labels and buttons of the game
    createLabelsAndButtons();
}


function createLabelsAndButtons(){
    //creates styles for different labels to use
    let labelStyle = new PIXI.TextStyle({
		fill: 0x00FF00,
        anchor: (0.5,0.5),
		fontSize: 56,
		fontFamily: "Bungee"
	});
    let smallLabelStyle = new PIXI.TextStyle({
		fill: 0x00FF00,
        anchor: (0.5,0.5),
		fontSize: 24,
		fontFamily: "Bungee"
	});
    let smallerLabelStyle = new PIXI.TextStyle({
		fill: 0x00FF00,
        anchor: (0.5,0.5),
		fontSize: 12,
		fontFamily: "Bungee"
	});
    //MAIN MENU
    //Title Labels
    titleLabel = new PIXI.Text("You");
	titleLabel.style = labelStyle;
	titleLabel.x = (sceneWidth/2)-58;
	titleLabel.y = 100;
    startScene.addChild(titleLabel);
    
    let titleLabel2 = new PIXI.Text("Save");
	titleLabel2.style = labelStyle;
	titleLabel2.x = (sceneWidth/2)-70;
	titleLabel2.y = 150;
    startScene.addChild(titleLabel2);
    
    let titleLabel3 = new PIXI.Text("The");
	titleLabel3.style = labelStyle;
	titleLabel3.x = (sceneWidth/2)-58;
	titleLabel3.y = 200;
    startScene.addChild(titleLabel3);
    
    let titleLabel4 = new PIXI.Text("Internet");
	titleLabel4.style = labelStyle;
	titleLabel4.x = (sceneWidth/2)-128;
	titleLabel4.y = 250;
    startScene.addChild(titleLabel4);
    //Start Label
    let startLabel = new PIXI.Text("START SAVING");
	startLabel.style.fill = 0x0000FF;
    startLabel.style.fontSize = 64;
    startLabel.style.fontFamily = "Bungee";
	startLabel.x = (sceneWidth/2)-230;
	startLabel.y = 700;
    startLabel.interactive = true;
	startLabel.buttonMode = true;
    startLabel.on("pointerup", mainMenu); //mainMenu is a funciton reference
	startLabel.on('pointerover', e=>e.target.alpha = 0.7);//concise arrow function with no brackets
	startLabel.on('pointerout', e=>e.currentTarget.alpha = 1.0);
    startScene.addChild(startLabel);
    //UPGRADE MENU
    //Arrow to game
    let leftArrow = new Arrow(100, 700, "Left");
    leftArrow.scale.set(0.3);
    leftArrow.interactive = true;
	leftArrow.buttonMode = true;
    leftArrow.on("pointerup", gameScreen); //gameScreen is a funciton reference
	leftArrow.on('pointerover', e=>e.target.alpha = 0.7);//concise arrow function with no brackets
	leftArrow.on('pointerout', e=>e.currentTarget.alpha = 1.0);
    shopScene.addChild(leftArrow);
    //Arrow to menu 2
    let rightArrow = new Arrow(700, 700, "Right");
    rightArrow.scale.set(0.3);
    rightArrow.interactive = true;
	rightArrow.buttonMode = true;
    rightArrow.on("pointerup", menu2); //menu2 is a funciton reference
	rightArrow.on('pointerover', e=>e.target.alpha = 0.7);//concise arrow function with no brackets
	rightArrow.on('pointerout', e=>e.currentTarget.alpha = 1.0);
    shopScene.addChild(rightArrow);
    //Money Label
    scoreLabel = new PIXI.Text(`Bytes: ${score}`);
	scoreLabel.style = labelStyle;
	scoreLabel.x = 0;
	scoreLabel.y = 50;
    shopScene.addChild(scoreLabel);
    //Bps label
    bpsLabel = new PIXI.Text(`Bps: ${bps}`);
	bpsLabel.style = labelStyle;
	bpsLabel.x = 300;
	bpsLabel.y = 720;
    shopScene.addChild(bpsLabel);
    //Clarity and help Labels
    menuLabel1 = new PIXI.Text("This menu upgrades your Bytes Per Second '(Bps)'");
	menuLabel1.style = smallLabelStyle;
	menuLabel1.x = 70;
	menuLabel1.y = 600;
    shopScene.addChild(menuLabel1);
    let arrowLabel1 = new PIXI.Text("To Game");
	arrowLabel1.style = smallerLabelStyle;
	arrowLabel1.x = 70;
	arrowLabel1.y = 760;
    shopScene.addChild(arrowLabel1);
    let arrowLabel2 = new PIXI.Text("To Menu Two");
	arrowLabel2.style = smallerLabelStyle;
	arrowLabel2.x = 650;
	arrowLabel2.y = 760;
    shopScene.addChild(arrowLabel2); 
    //earth image
    let earth = new Earth();
    earth.scale.set(0.7);
    earth.x = 250;
    earth.y = 270;
    shopScene.addChild(earth);
    //8 buttons for upgrades
    miniMiner = new Upgrade(1, miniMinerScore, "Mini Miner", "images/miner.png", 1, "Bps");
    miniMiner.addLabels();
    miniMiner.img.scale.set(0.01); 
    miniMiner.x = 40;
    miniMiner.y = 200;
    miniMiner.on('pointerup', miniMiner.buyUpgrade);//buyUpgrade is a function reference
	miniMiner.on('pointerover', e=>e.target.alpha = 0.7);
	miniMiner.on('pointerout', e=>e.currentTarget.alpha = 1.0);
    shopScene.addChild(miniMiner);
    miner = new Upgrade(10, localStorage.getItem("Miners"), "Miner", "images/miner.png", 5, "Bps");
    miner.addLabels();
    miner.img.x = 7;
    miner.img.y = 10;
    miner.img.scale.set(0.03); 
    miner.x = 20;
    miner.y = 300;
    miner.on('pointerup',miner.buyUpgrade);//buyUpgrade is a function reference
	miner.on('pointerover', e=>e.target.alpha = 0.7);
	miner.on('pointerout', e=>e.currentTarget.alpha = 1.0);
    shopScene.addChild(miner);
    megaMiner = new Upgrade(100, localStorage.getItem("MegaMiners"), "Mega Miner", "images/miner.png", 50, "Bps");
    megaMiner.addLabels();
    megaMiner.img.x = 5;
    megaMiner.img.y = 0;
    megaMiner.img.scale.set(0.05); 
    megaMiner.x = 20;
    megaMiner.y = 400;
    megaMiner.on('pointerup', megaMiner.buyUpgrade);//buyUpgrade is a function reference
	megaMiner.on('pointerover', e=>e.target.alpha = 0.7);
	megaMiner.on('pointerout', e=>e.currentTarget.alpha = 1.0);
    shopScene.addChild(megaMiner);
    minerManager = new Upgrade(1000, localStorage.getItem("MinerManagers"), "Miner Manager", "images/manager.png", 500, "Bps");
    minerManager.addLabels();
    minerManager.img.y = 6;
    minerManager.img.scale.set(0.15); 
    minerManager.x = 40;
    minerManager.y = 500;
    minerManager.on('pointerup', minerManager.buyUpgrade);//buyUpgrade is a function reference
	minerManager.on('pointerover', e=>e.target.alpha = 0.7);
	minerManager.on('pointerout', e=>e.currentTarget.alpha = 1.0);
    shopScene.addChild(minerManager);
    claw = new Upgrade(2000, localStorage.getItem("ClawMiners"), "Mining Claw", "images/claw.png", 1000, "Bps");
    claw.addLabels();
    claw.img.y = 6;
    claw.img.scale.set(0.1); 
    claw.x = 540;
    claw.y = 200;
    claw.on('pointerup', claw.buyUpgrade);//buyUpgrade is a function reference
	claw.on('pointerover', e=>e.target.alpha = 0.7);
	claw.on('pointerout', e=>e.currentTarget.alpha = 1.0);
    shopScene.addChild(claw);
    explosives = new Upgrade(4000, localStorage.getItem("HTMLExplosives"), "HTML Explosives", "images/explosives.png", 2000, "Bps");
    explosives.addLabels();
    explosives.img.y = 6;
    explosives.img.scale.set(0.11); 
    explosives.x = 560;
    explosives.y = 300;
    explosives.on('pointerup', explosives.buyUpgrade);//buyUpgrade is a function reference
	explosives.on('pointerover', e=>e.target.alpha = 0.7);
	explosives.on('pointerout', e=>e.currentTarget.alpha = 1.0);
    shopScene.addChild(explosives);
    hacker = new Upgrade(6000, localStorage.getItem("80sHackers"), "80s Hackers", "images/hacker.png", 3000, "Bps");
    hacker.addLabels();
    hacker.img.y = 6;
    hacker.img.scale.set(0.22); 
    hacker.x = 560;
    hacker.y = 400;
    hacker.on('pointerup', hacker.buyUpgrade);//buyUpgrade is a function reference
	hacker.on('pointerover', e=>e.target.alpha = 0.7);
	hacker.on('pointerout', e=>e.currentTarget.alpha = 1.0);
    shopScene.addChild(hacker);
    keyboard = new Upgrade(12000, localStorage.getItem("ExtraKeyboards"), "Extra Keyboard", "images/keyboard.png", 6000, "Bps");
    keyboard.addLabels();
    keyboard.img.y = 10;
    keyboard.img.scale.set(0.07); 
    keyboard.x = 540;
    keyboard.y = 500;
    keyboard.on('pointerup', keyboard.buyUpgrade);//buyUpgrade is a function reference
	keyboard.on('pointerover', e=>e.target.alpha = 0.7);
	keyboard.on('pointerout', e=>e.currentTarget.alpha = 1.0);
    shopScene.addChild(keyboard);
    //SECOND MENU
    //MoneyLabel
    scoreLabel2 = new PIXI.Text(`Bytes: ${score}`);
	scoreLabel2.style = labelStyle;
	scoreLabel2.x = 0;
	scoreLabel2.y = 50;
    shopScene2.addChild(scoreLabel2);
    //Click Power Label
    clickPowerLabel = new PIXI.Text(`Arrow Power: ${clickPower}`);
	clickPowerLabel.style = labelStyle;
	clickPowerLabel.x = 150;
	clickPowerLabel.y = 720;
    shopScene2.addChild(clickPowerLabel);
    //Clarity Labels
    menuLabel2 = new PIXI.Text("This menu upgrades your Arrow Power,");
	menuLabel2.style = smallLabelStyle;
	menuLabel2.x = 130;
	menuLabel2.y = 570;
    shopScene2.addChild(menuLabel2);
    let menuLabel3 = new PIXI.Text("or how many Bytes each minigame arrow gives you");
	menuLabel3.style = smallLabelStyle;
	menuLabel3.x = 50;
	menuLabel3.y = 600;
    shopScene2.addChild(menuLabel3);
    let arrowLabel3 = new PIXI.Text("To Menu One");
	arrowLabel3.style = smallerLabelStyle;
	arrowLabel3.x = 40;
	arrowLabel3.y = 760;
    shopScene2.addChild(arrowLabel3);
    //earth image
    let earth2 = new Earth();
    earth2.scale.set(0.7);
    earth2.x = 250;
    earth2.y = 270;
    shopScene2.addChild(earth2);
    //8 buttons for upgrades
    bytes = new Upgrade(1, localStorage.getItem("ByteBonus"), "Byte", "images/byte.png", 1, "Power");
    bytes.addLabels();
    bytes.img.y = 10;
    bytes.img.scale.set(0.08); 
    bytes.x = 40;
    bytes.y = 200;
    bytes.on('pointerup', bytes.buyUpgrade);//buyUpgrade is a function reference
	bytes.on('pointerover', e=>e.target.alpha = 0.7);
	bytes.on('pointerout', e=>e.currentTarget.alpha = 1.0);
    shopScene2.addChild(bytes);
    shorts = new Upgrade(10, localStorage.getItem("ShortBonus"), "Short", "images/short.png", 5, "Power");
    shorts.addLabels();
    shorts.img.x = 7;
    shorts.img.y = 10;
    shorts.img.scale.set(0.08); 
    shorts.x = 20;
    shorts.y = 300;
    shorts.on('pointerup', shorts.buyUpgrade);//buyUpgrade is a function reference
	shorts.on('pointerover', e=>e.target.alpha = 0.7);
	shorts.on('pointerout', e=>e.currentTarget.alpha = 1.0);
    shopScene2.addChild(shorts);
    ints = new Upgrade(100, localStorage.getItem("IntBonus"), "Int", "images/int.png", 50, "Power");
    ints.addLabels();
    ints.img.x = 7;
    ints.img.y = 7;
    ints.img.scale.set(0.35); 
    ints.x = 20;
    ints.y = 400;
    ints.on('pointerup', ints.buyUpgrade);//buyUpgrade is a function reference
	ints.on('pointerover', e=>e.target.alpha = 0.7);
	ints.on('pointerout', e=>e.currentTarget.alpha = 1.0);
    shopScene2.addChild(ints);
    longs = new Upgrade(1000, localStorage.getItem("LongBonus"), "Long", "images/long.png", 500, "Power");
    longs.addLabels();
    longs.img.x = 15;
    longs.img.y = 20;
    longs.img.scale.set(0.07); 
    longs.x = 40;
    longs.y = 500;
    longs.on('pointerup', longs.buyUpgrade);//buyUpgrade is a function reference
	longs.on('pointerover', e=>e.target.alpha = 0.7);
	longs.on('pointerout', e=>e.currentTarget.alpha = 1.0);
    shopScene2.addChild(longs);
    floats = new Upgrade(2000, localStorage.getItem("FloatBonus"), "Float", "images/float.png", 1000, "Power");
    floats.addLabels();
    floats.img.y = 7;
    floats.img.scale.set(0.08); 
    floats.x = 540;
    floats.y = 200;
    floats.on('pointerup', floats.buyUpgrade);//buyUpgrade is a function reference
	floats.on('pointerover', e=>e.target.alpha = 0.7);
	floats.on('pointerout', e=>e.currentTarget.alpha = 1.0);
    shopScene2.addChild(floats);
    doubles = new Upgrade(4000, localStorage.getItem("DoubleBonus"), "Double", "images/double.png", 2000, "Power");
    doubles.addLabels();
    doubles.img.x = 10;
    doubles.img.y = 11;
    doubles.img.scale.set(0.3); 
    doubles.x = 560;
    doubles.y = 300;
    doubles.on('pointerup', floats.buyUpgrade);//buyUpgrade is a function reference
	doubles.on('pointerover', e=>e.target.alpha = 0.7);
	doubles.on('pointerout', e=>e.currentTarget.alpha = 1.0);
    shopScene2.addChild(doubles);
    chars = new Upgrade(6000, localStorage.getItem("CharBonus"), "Char", "images/char.png", 3000, "Power");
    chars.addLabels();
    chars.img.y = 6;
    chars.img.scale.set(0.18); 
    chars.x = 560;
    chars.y = 400;
    chars.on('pointerup', chars.buyUpgrade);//buyUpgrade is a function reference
	chars.on('pointerover', e=>e.target.alpha = 0.7);
	chars.on('pointerout', e=>e.currentTarget.alpha = 1.0);
    shopScene2.addChild(chars);
    bools = new Upgrade(12000, localStorage.getItem("BoolBonus"), "Bool", "images/bool.png", 6000, "Power");
    bools.addLabels();
    bools.img.x = 10;
    bools.img.y = 12;
    bools.img.scale.set(0.07); 
    bools.x = 540;
    bools.y = 500;
    bools.on('pointerup', bools.buyUpgrade);//buyUpgrade is a function reference
	bools.on('pointerover', e=>e.target.alpha = 0.7);
	bools.on('pointerout', e=>e.currentTarget.alpha = 1.0);
    shopScene2.addChild(bools);
    //arrow to main menu
    let leftArrowMenu2 = new Arrow(100, 700, "Left");
    leftArrowMenu2.scale.set(0.3);
    leftArrowMenu2.interactive = true;
	leftArrowMenu2.buttonMode = true;
    leftArrowMenu2.on("pointerup", mainMenu); //gameLoop is a funciton reference
	leftArrowMenu2.on('pointerover', e=>e.target.alpha = 0.7);
	leftArrowMenu2.on('pointerout', e=>e.currentTarget.alpha = 1.0);
    shopScene2.addChild(leftArrowMenu2);
    //GAME SCREEN
    //bottom 4 arrow indicators
    leftIndicator = new Arrow(100, 480, "Left");
    leftIndicator.scale.set(0.3);
    leftIndicator.alpha = 0.5;
    gameScene.addChild(leftIndicator);
    upIndicator = new Arrow(300, 480, "Up");
    upIndicator.scale.set(0.3);
    upIndicator.alpha = 0.5;
    gameScene.addChild(upIndicator);
    downIndicator = new Arrow(500, 480, "Down");
    downIndicator.scale.set(0.3);
    downIndicator.alpha = 0.5;
    gameScene.addChild(downIndicator);
    rightIndicator = new Arrow(700, 480, "Right");
    rightIndicator.scale.set(0.3);
    rightIndicator.alpha = 0.5;
    gameScene.addChild(rightIndicator);
    //score label
    localLabel = new PIXI.Text(`Score: ${localScore}`);
	localLabel.style = smallLabelStyle;
	localLabel.x = 330;
	localLabel.y = 650;
    gameScene.addChild(localLabel);
    //music buttons
    //music button style
    let newLabelStyle = new PIXI.TextStyle({
		fill: 0x00FF00,
        anchor: (0.5,0.5),
		fontSize: 18,
		fontFamily: "Bungee"
	});
    let musicLabel = new PIXI.Text("Pick some music to listen to!");
	musicLabel.style = newLabelStyle;
	musicLabel.x = 240;
	musicLabel.y = 700;
    gameScene.addChild(musicLabel);
    //music buttons and the mute button
    let musicButton1 = new Music("We Are", track1);
    musicButton1.x = 200;
    musicButton1.y = 720;
    musicButton1.interactive = true;
	musicButton1.buttonMode = true;
    musicButton1.on("pointerup", musicButton1.playTrack); //mainMenu is a funciton reference
	musicButton1.on('pointerover', e=>e.target.alpha = 0.7);//concise arrow function with no brackets
	musicButton1.on('pointerout', e=>e.currentTarget.alpha = 1.0);
    soundArr.push(musicButton1);
    gameScene.addChild(musicButton1);
    let musicButton2 = new Music("Get Back", track2);
    musicButton2.x = 300;
    musicButton2.y = 720;
    musicButton2.interactive = true;
	musicButton2.buttonMode = true;
    musicButton2.on("pointerup", musicButton2.playTrack); //mainMenu is a funciton reference
	musicButton2.on('pointerover', e=>e.target.alpha = 0.7);//concise arrow function with no brackets
	musicButton2.on('pointerout', e=>e.currentTarget.alpha = 1.0);
    soundArr.push(musicButton2);
    gameScene.addChild(musicButton2);
    let musicButton3 = new Music("Byte", track3);
    musicButton3.x = 400;
    musicButton3.y = 720;
    musicButton3.interactive = true;
	musicButton3.buttonMode = true;
    musicButton3.on("pointerup", musicButton3.playTrack); //mainMenu is a funciton reference
	musicButton3.on('pointerover', e=>e.target.alpha = 0.7);//concise arrow function with no brackets
	musicButton3.on('pointerout', e=>e.currentTarget.alpha = 1.0);
    soundArr.push(musicButton3);
    gameScene.addChild(musicButton3);
    let muteButton = new Music("Mute All", track3);
    muteButton.x = 500;
    muteButton.y = 720;
    muteButton.interactive = true;
	muteButton.buttonMode = true;
    muteButton.on("pointerup", mute); //mainMenu is a funciton reference
	muteButton.on('pointerover', e=>e.target.alpha = 0.7);//concise arrow function with no brackets
	muteButton.on('pointerout', e=>e.currentTarget.alpha = 1.0);
    gameScene.addChild(muteButton);
    //arrow back to main menu
    let rightArrow2 = new Arrow(700, 700, "Right");
    rightArrow2.scale.set(0.3);
    rightArrow2.interactive = true;
	rightArrow2.buttonMode = true;
    rightArrow2.on("pointerup", mainMenu); //mainMenu is a funciton reference
	rightArrow2.on('pointerover', e=>e.target.alpha = 0.7);//concise arrow function with no brackets
	rightArrow2.on('pointerout', e=>e.currentTarget.alpha = 1.0);
    gameScene.addChild(rightArrow2);
    let arrowLabel4 = new PIXI.Text("To Menu One");
	arrowLabel4.style = smallerLabelStyle;
	arrowLabel4.x = 650;
	arrowLabel4.y = 760;
    gameScene.addChild(arrowLabel4);
    storeValues(score, bps, clickPower, highScore, miniMiner.amount, miner.amount, megaMiner.amount, minerManager.amount, claw.amount, explosives.amount, hacker.amount, keyboard.amount, bytes.amount, shorts.amount, ints.amount, longs.amount, floats.amount, doubles.amount, chars.amount, bools.amount);
}

//mutes all the sounds
function mute(){
    for(let s of soundArr){
            s.stopTrack();
        }
}

//when the main menu is accessed
function mainMenu(){
	startScene.visible = false;
	gameScene.visible = false;
    shopScene2.visible = false;
	shopScene.visible = true;
    clearInterval(gameLoop);
    clearInterval(updateMovement);
}

//idle function to run
function idle(){
    //ads the Bytes per second to the score
    score+=bps/60;
    //determines the display of each label
    if(score >1000 && score<1000000){
       scoreLabel.text = `Kilobytes: ${Math.floor(score/1000)}KB`;
       scoreLabel2.text = `Kilobytes: ${Math.floor(score/1000)}KB`;
       }else
    if(score >1000000 && score<1000000000){
       scoreLabel.text = `Megabytes: ${Math.floor(score/1000000)}MB`;
       scoreLabel2.text = `Megabytes: ${Math.floor(score/1000000)}MB`;
       }else
    if(score >1000000000 && score<1000000000000){
       scoreLabel.text = `Gigabytes: ${Math.floor(score/1000000000)}GB`;
       scoreLabel2.text = `Gigabytes: ${Math.floor(score/1000000000)}GB`;
       }else
    if(score >1000000000000 && score<1000000000000000){
       scoreLabel.text = `Terabytes: ${Math.floor(score/1000000000000)}TB`;
       scoreLabel2.text = `Terabytes: ${Math.floor(score/1000000000000)}TB`;
       }else
    if(score >1000000000000000 && score<1000000000000000000){
       scoreLabel.text = `Petabytes: ${Math.floor(score/1000000000000000)}PB`;
       scoreLabel2.text = `Petabytes: ${Math.floor(score/1000000000000000)}PB`;
       }else
    if(score >1000000000000000000){
       scoreLabel.text = `Exabytes: ${Math.floor(score/1000000000000000000)}EB`;
       scoreLabel2.text = `Exabytes: ${Math.floor(score/1000000000000000000)}EB`;
       }else{
           scoreLabel.text = `Bytes: ${Math.floor(score)}`;
           scoreLabel2.text = `Bytes: ${Math.floor(score)}`;
       }
    
    if(bps >1000 && bps<1000000){
       bpsLabel.text = `KBps: ${Math.floor(bps/1000)}`;
       }else
    if(bps >1000000 && bps<1000000000){
       bpsLabel.text = `MBps: ${Math.floor(bps/1000000)}`;
       }else
    if(bps >1000000000 && bps<1000000000000){
       bpsLabel.text = `GBps: ${Math.floor(bps/1000000000)}`;
       }else
    if(bps >1000000000000 && bps<1000000000000000){
       bpsLabel.text = `TBps: ${Math.floor(bps/1000000000000)}`;
       }else
    if(bps >1000000000000000 && bps<1000000000000000){
       bpsLabel.text = `PBps: ${Math.floor(bps/1000000000000000)}`;
       }else
    if(bps >1000000000000000000){
       bpsLabel.text = `EBps: ${Math.floor(bps/1000000000000000000)}`;
       }else{
           bpsLabel.text = `Bps: ${Math.floor(bps)}`;
       }
    
    if(clickPower >1000 && clickPower<1000000){
       clickPowerLabel.text = `Arrow Power: ${Math.floor(clickPower/1000)}KB`;
       }else
    if(clickPower >1000000 && clickPower<1000000000){
       clickPowerLabel.text = `Arrow Power: ${Math.floor(clickPower/1000000)}MB`;
       }else
    if(clickPower >1000000000 && clickPower<1000000000000){
       clickPowerLabel.text = `Arrow Power: ${Math.floor(clickPower/1000000000)}GB`;
       }else
    if(clickPower >1000000000000 && clickPower<1000000000000000){
       clickPowerLabel.text = `Arrow Power: ${Math.floor(clickPower/1000000000000)}TB`;
       }else
    if(clickPower >1000000000000000 && clickPower<1000000000000000000){
       clickPowerLabel.text = `Arrow Power: ${Math.floor(clickPower/1000000000000000)}PB`;
       }else
    if(clickPower >1000000000000000000){
       clickPowerLabel.text = `Arrow Power: ${Math.floor(clickPower/1000000000000000000)}EB`;
       }else{
           clickPowerLabel.text = `Arrow Power: ${Math.floor(clickPower)}B`;
       }
    //saves the scores for local storage
    miniMinerScore = miniMiner.amount;
    minerScore = miner.amount;
    megaMinerScore = megaMiner.amount; 
    managerScore = minerManager.amount;
    clawScore = claw.amount; 
    explosiveScore = explosives.amount; 
    hackerScore = hacker.amount;
    keyboardScore = keyboard.amount;
    byteScore = bytes.amount; 
    shortScore = shorts.amount; 
    intScore = ints.amount; 
    longScore = longs.amount;
    floatScore = floats.amount; 
    doubleScore = doubles.amount; 
    charScore = chars.amount;
    boolScore = bools.amount;
    //stores the values in local storage
    storeValues(score, bps, clickPower, highScore, miniMiner.amount, miner.amount, megaMiner.amount, minerManager.amount, claw.amount, explosives.amount, hacker.amount, keyboard.amount, bytes.amount, shorts.amount, ints.amount, longs.amount, floats.amount, doubles.amount, chars.amount, bools.amount);
    
}

//when menu2 is accessed
function menu2(){
    startScene.visible = false;
	gameScene.visible = false;
    shopScene.visible = false;
    shopScene2.visible = true;
}

//when the gameScreen is accessed
function gameScreen(){
    startScene.visible = false;
    shopScene.visible = false;
    shopScene2.visible = false;
    gameScene.visible = true;
}

//gameLoop that spawns new arrows
function gameLoop(){
    if(gameScene.visible == true && stop == false)
    {
        //spawn a new arrow of a random direction based on gameSpeed
        let randomDirection = Math.floor(Math.random()*4);
        if(randomDirection == 0){
            let arrow = new Arrow(100, -50, "Left");
            arrow.scale.set(0.3);
            arrows.push(arrow);
            gameScene.addChild(arrow);
        }
        if(randomDirection == 1){
            let arrow = new Arrow(300, -50, "Up");
            arrow.scale.set(0.3);
            arrows.push(arrow);
            gameScene.addChild(arrow);
        }
        if(randomDirection == 2){
            let arrow = new Arrow(500, -50, "Down");
            arrow.scale.set(0.3);
            arrows.push(arrow);
            gameScene.addChild(arrow);
        }
        if(randomDirection == 3){
            let arrow = new Arrow(700, -50, "Right");
            arrow.scale.set(0.3);
            arrows.push(arrow);
            gameScene.addChild(arrow);
        }
        
    }
}

//updates the arrow movements, determines if a player misses an arrow
function updateMovement(){
    if(gameScene.visible == true && stop == false){
        localLabel.text = `Score: ${localScore}`;
        for(let a of arrows){
            a.move();
            if(a.y > 620){
                endGame();
            }
        }
    arrows = arrows.filter(a=>a.y <800);
    }
}

//handles the key presses of the game
function onKeyDown(key){
    if(key.keyCode == 37){
        if(gameScene.visible == true && stop == false){
            let hit=false;
            //checks if each arrow is intersecting this type of arrow
            for(let a of arrows)
            {
            if(rectsIntersect(a, leftIndicator)){
                hit =true;
                a.hit = true;
                gameScene.removeChild(a);
            }
            }
            //if the player hit the arrow, does all the actions that go with that
            if(hit == true){
                localScore += 1;
                score += clickPower;
                gameSpeed -= 150;
                hit = false;
                arrows = arrows.filter(a=>a.hit ==false);
            }else{
                //if nothing was hit or was incorrect end the game
                endGame();
            }
        }
    }
    if(key.keyCode == 38){
        //prevents scrolling
        key.preventDefault();
        if(gameScene.visible == true && stop == false){
            let hit=false;
            //checks if each arrow is intersecting this type of arrow
            for(let a of arrows)
            {
            if(rectsIntersect(a, upIndicator)){
                hit =true;
                a.hit = true;
                gameScene.removeChild(a);
            }
            }
            
            //if the player hit the arrow, does all the actions that go with that
            if(hit == true){
                localScore += 1;
                score += clickPower;
                gameSpeed -= 150;
                hit = false;
                arrows = arrows.filter(a=>a.hit ==false);
            }else{
                endGame();
            }
        }
    }
    if(key.keyCode == 40){
        key.preventDefault();
        if(gameScene.visible == true && stop == false){
            let hit=false;
            //checks if each arrow is intersecting this type of arrow
            for(let a of arrows)
            {
            if(rectsIntersect(a, downIndicator)){
                hit =true;
                a.hit = true;
                gameScene.removeChild(a);
            }
            }
            //if the player hit the arrow, does all the actions that go with that
            if(hit == true){
                localScore += 1;
                score += clickPower;
                gameSpeed -= 150;
                hit = false;
                arrows = arrows.filter(a=>a.hit ==false);
            }else{
                endGame();
            }
        }
    }
    if(key.keyCode == 39){
        if(gameScene.visible == true && stop == false){
            let hit=false;
            //checks if each arrow is intersecting this type of arrow
            for(let a of arrows)
            {
            if(rectsIntersect(a, rightIndicator)){
                hit =true;
                a.hit = true;
                gameScene.removeChild(a);
            }
            }
            //if the player hit the arrow, does all the actions that go with that
            if(hit == true){
                localScore += 1;
                score += clickPower;
                gameSpeed -= 75;
                hit = false;
                arrows = arrows.filter(a=>a.hit ==false);
            }else{
                endGame();
            }
        }
    }
}

//when the game ends this will run
function endGame(){
    stop = true;
    let labelStyle = new PIXI.TextStyle({
		fill: 0x00FF00,
        anchor: (0.5,0.5),
		fontSize: 48,
		fontFamily: "Bungee"
	});
    //sets the higscore if applicable
    if(localScore > highScore){
        highScore = localScore;
    }
    //Game over labels
    gameScoreLabel = new PIXI.Text(`You lost. Score: ${localScore}`);
	gameScoreLabel.style = labelStyle;
	gameScoreLabel.x = 150;
	gameScoreLabel.y = 300;
    gameScene.addChild(gameScoreLabel);
    highScoreLabel = new PIXI.Text(`High Score: ${highScore}`);
	highScoreLabel.style = labelStyle;
	highScoreLabel.x = 200;
	highScoreLabel.y = 750;
    gameScene.addChild(highScoreLabel);
    playAgainLabel = new PIXI.Text(`Play Again? Click Here!`);
	playAgainLabel.style = labelStyle;
	playAgainLabel.x = 70;
	playAgainLabel.y = 400;
    playAgainLabel.interactive = true;
	playAgainLabel.buttonMode = true;
    playAgainLabel.on("pointerup", startGame); //startGame is a funciton reference
	playAgainLabel.on('pointerover', e=>e.target.alpha = 0.7);//concise arrow function with no brackets
	playAgainLabel.on('pointerout', e=>e.currentTarget.alpha = 1.0);
    gameScene.addChild(playAgainLabel);
    localScore = 0;
    //clean up of arrows
    for(let a of arrows)
    {
        gameScene.removeChild(a);
    }
    arrows = [];
    //resets game speed
    gameSpeed = 10000; 
}

//when the gameStarts cleans up and then starts it
function startGame(){
    stop = false;
    gameScene.removeChild(gameScoreLabel);
    gameScene.removeChild(highScoreLabel);
    gameScene.removeChild(playAgainLabel);
}
